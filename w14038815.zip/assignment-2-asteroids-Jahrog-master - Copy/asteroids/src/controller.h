/* 
    Jacob Roling
	w14038815
*/

/* Main control method */
void controls(void);
