/* 
    Jacob Roling
	w14038815
*/

/* Game state */

extern float e_time; /* played time */
extern int   currentscore;        /* currentscore */
extern int   lifesleft;        /* lifesleft */
extern int shield;				 /* shield*/
extern bool paused;				 /* pauses */
extern struct ship player; /* position */

extern const float Dt; /* needed for motion */
