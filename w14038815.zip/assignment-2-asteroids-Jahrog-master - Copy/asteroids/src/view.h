/* 
    Jacob Roling
	w14038815
*/

/* support double buffering */
void init_DBuffer(void);
void swap_DBuffer(void);

/* Main draw method */
void draw(void);
